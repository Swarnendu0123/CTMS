import './App.css'
import Teams from './components/Teams'
function App() {

  return (
    <>
    <div className='flex'>
        <Teams/> 
    </div>
    </>
  )
}

export default App
