import {
    atom,
} from 'recoil';

export const matchData = atom({
    key: 'matchData',
    default: [],
});